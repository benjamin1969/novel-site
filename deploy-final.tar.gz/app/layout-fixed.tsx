// 🧱 修复的根布局 - 使用外部CSS避免水合错误
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: '简阅小说平台',
  description: '小学生专属的原创小说天地',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh-CN">
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style dangerouslySetInnerHTML={{
          __html: `
            /* 基础重置 */
            * { margin: 0; padding: 0; box-sizing: border-box; }
            
            /* 全局样式 */
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              background: hsl(40, 20%, 98%); /* 米色背景 */
              color: #111827;
              line-height: 1.5;
              min-height: 100vh;
            }
            
            /* 容器 */
            .container {
              width: 100%;
              max-width: 1200px;
              margin: 0 auto;
              padding: 0 1rem;
            }
            
            /* 导航栏 */
            .navbar {
              background: white;
              border-bottom: 1px solid #e5e7eb;
              padding: 1rem 0;
              position: sticky;
              top: 0;
              z-index: 50;
              box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            
            .nav-content {
              display: flex;
              align-items: center;
              justify-content: space-between;
            }
            
            .logo {
              display: flex;
              align-items: center;
              gap: 0.75rem;
              text-decoration: none;
              color: inherit;
            }
            
            .logo-box {
              width: 40px;
              height: 40px;
              background: #2563eb;
              border-radius: 8px;
              display: flex;
              align-items: center;
              justify-content: center;
              color: white;
              font-weight: bold;
              font-size: 1.25rem;
            }
            
            .logo-text h1 {
              font-size: 1.25rem;
              font-weight: bold;
              color: #111827;
            }
            
            .logo-text p {
              font-size: 0.75rem;
              color: #6b7280;
            }
            
            /* 导航链接 */
            .nav-links {
              display: flex;
              gap: 1rem;
            }
            
            .nav-link {
              color: #374151;
              text-decoration: none;
              padding: 0.5rem 1rem;
              border-radius: 6px;
              transition: all 0.2s;
            }
            
            .nav-link:hover {
              color: #2563eb;
              background: #f9fafb;
            }
            
            /* 用户操作 */
            .nav-actions {
              display: flex;
              align-items: center;
              gap: 1rem;
            }
            
            .btn {
              padding: 0.5rem 1rem;
              border-radius: 6px;
              text-decoration: none;
              font-weight: 500;
              transition: all 0.2s;
            }
            
            .btn-login {
              color: #374151;
            }
            
            .btn-login:hover {
              color: #2563eb;
            }
            
            .btn-register {
              background: #2563eb;
              color: white;
            }
            
            .btn-register:hover {
              background: #1d4ed8;
            }
            
            /* 主内容 */
            main {
              padding: 2rem 0;
              min-height: calc(100vh - 160px);
            }
            
            /* 页脚 */
            footer {
              border-top: 1px solid #e5e7eb;
              background: white;
              padding: 2rem 0;
              text-align: center;
            }
            
            footer p {
              color: #6b7280;
              margin-bottom: 0.5rem;
            }
            
            /* 响应式 */
            @media (max-width: 768px) {
              .nav-content {
                flex-direction: column;
                gap: 1rem;
              }
              
              .nav-links {
                flex-wrap: wrap;
                justify-content: center;
              }
              
              .nav-actions {
                margin-top: 0.5rem;
              }
            }
          `
        }} />
      </head>
      <body>
        {/* 导航栏 */}
        <header className="navbar">
          <div className="container">
            <div className="nav-content">
              {/* Logo */}
              <a href="/" className="logo">
                <div className="logo-box">阅</div>
                <div className="logo-text">
                  <h1>简阅</h1>
                  <p>小说创作平台</p>
                </div>
              </a>
              
              {/* 导航链接 */}
              <nav className="nav-links">
                <a href="/" className="nav-link">首页</a>
                <a href="/novels" className="nav-link">发现</a>
                <a href="/novels/new" className="nav-link">创作</a>
                <a href="/my-novels" className="nav-link">我的作品</a>
              </nav>
              
              {/* 用户操作 */}
              <div className="nav-actions">
                <a href="/login" className="btn btn-login">登录</a>
                <a href="/register" className="btn btn-register">注册</a>
              </div>
            </div>
          </div>
        </header>
        
        {/* 主内容 */}
        <main className="container">
          {children}
        </main>
        
        {/* 页脚 */}
        <footer>
          <div className="container">
            <p>© 2024 简阅 · 专为创作者设计的简约发布空间</p>
            <p style={{ fontSize: '0.875rem' }}>
              一个专注于阅读和创作的简约平台，让每个故事都能被看见
            </p>
          </div>
        </footer>
      </body>
    </html>
  )
}